<?php
$numberOfResults = 5;