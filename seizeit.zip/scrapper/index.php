<?php
require_once __DIR__."/functions.php";
    echo "<a href='generate.php'>Generate {$numberOfResults} results</a>";
?>