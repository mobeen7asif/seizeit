document.htmlbox_syntax=function(){
return [
    [
	'Actionscript',
    '<br /><div style="position:relative;top:10px;left:10px;font-size:11px;font-family:verdana;">Actionscript Code</div><div class="asp" contenteditable="true" style="border:1px dashed silver;margin:10px;padding:5px;background:cornsilk;font-family:monospace;font-size:12px;">',
    '</div><br />'
	],
	[
	'ADA',
    '<br /><div style="position:relative;top:10px;left:10px;font-size:11px;font-family:verdana;">ADA Code</div><div class="asp" contenteditable="true" style="border:1px dashed silver;margin:10px;padding:5px;background:cornsilk;font-family:monospace;font-size:12px;">',
    '</div><br />'
	],
	[
	'Applescript',
    '<br /><div style="position:relative;top:10px;left:10px;font-size:11px;font-family:verdana;">Applescript Code</div><div class="asp" contenteditable="true" style="border:1px dashed silver;margin:10px;padding:5px;background:cornsilk;font-family:monospace;font-size:12px;">',
    '</div><br />'
	],
    [
	'ASP',
    '<br /><div style="position:relative;top:10px;left:10px;font-size:11px;font-family:verdana;">ASP Code</div><div class="asp" contenteditable="true" style="border:1px dashed silver;margin:10px;padding:5px;background:cornsilk;font-family:monospace;font-size:12px;">',
    '</div><br />'
	],
	[
	'Basic',
    '<br /><div style="position:relative;top:10px;left:10px;font-size:11px;font-family:verdana;">Basic Code</div><div class="asp" contenteditable="true" style="border:1px dashed silver;margin:10px;padding:5px;background:cornsilk;font-family:monospace;font-size:12px;">',
    '</div><br />'
	],
	[
	'C#',
    '<br /><div style="position:relative;top:10px;left:10px;font-size:11px;font-family:verdana;">C# Code</div><div class="asp" contenteditable="true" style="border:1px dashed silver;margin:10px;padding:5px;background:cornsilk;font-family:monospace;font-size:12px;">',
    '</div><br />'
	],
	[
	'C++',
    '<br /><div style="position:relative;top:10px;left:10px;font-size:11px;font-family:verdana;">C++ Code</div><div class="asp" contenteditable="true" style="border:1px dashed silver;margin:10px;padding:5px;background:cornsilk;font-family:monospace;font-size:12px;">',
    '</div><br />'
	],
	[
	'ColdFusion',
    '<br /><div style="position:relative;top:10px;left:10px;font-size:11px;font-family:verdana;">ColdFusion Code</div><div class="asp" contenteditable="true" style="border:1px dashed silver;margin:10px;padding:5px;background:cornsilk;font-family:monospace;font-size:12px;">',
    '</div><br />'
	],
	[
	'CSS',
    '<br /><div style="position:relative;top:10px;left:10px;font-size:11px;font-family:verdana;"CSS Code</div><div class="asp" contenteditable="true" style="border:1px dashed silver;margin:10px;padding:5px;background:cornsilk;font-family:monospace;font-size:12px;">',
    '</div><br />'
	],
	[
	'HTML',
    '<br /><div style="position:relative;top:10px;left:10px;font-size:11px;font-family:verdana;">HTML Code</div><div class="asp" contenteditable="true" style="border:1px dashed silver;margin:10px;padding:5px;background:cornsilk;font-family:monospace;font-size:12px;">',
    '</div><br />'
	],
	[
	'Java',
    '<br /><div style="position:relative;top:10px;left:10px;font-size:11px;font-family:verdana;">Java Code</div><div class="asp" contenteditable="true" style="border:1px dashed silver;margin:10px;padding:5px;background:cornsilk;font-family:monospace;font-size:12px;">',
    '</div><br />'
	],
	[
	'JavaScript',
    '<br /><div style="position:relative;top:10px;left:10px;font-size:11px;font-family:verdana;">JavaScript Code</div><div class="asp" contenteditable="true" style="border:1px dashed silver;margin:10px;padding:5px;background:cornsilk;font-family:monospace;font-size:12px;">',
    '</div><br />'
	],
	[
	'Lisp',
    '<br /><div style="position:relative;top:10px;left:10px;font-size:11px;font-family:verdana;">Lisp Code</div><div class="asp" contenteditable="true" style="border:1px dashed silver;margin:10px;padding:5px;background:cornsilk;font-family:monospace;font-size:12px;">',
    '</div><br />'
	],
	[
	'Lua',
    '<br /><div style="position:relative;top:10px;left:10px;font-size:11px;font-family:verdana;">Lua Code</div><div class="asp" contenteditable="true" style="border:1px dashed silver;margin:10px;padding:5px;background:cornsilk;font-family:monospace;font-size:12px;">',
    '</div><br />'
	],
	[
	'MySQL',
    '<br /><div style="position:relative;top:10px;left:10px;font-size:11px;font-family:verdana;">MySQL Code</div><div class="asp" contenteditable="true" style="border:1px dashed silver;margin:10px;padding:5px;background:cornsilk;font-family:monospace;font-size:12px;">',
    '</div><br />'
	],
	[
	'Perl',
    '<br /><div style="position:relative;top:10px;left:10px;font-size:11px;font-family:verdana;">Perl Code</div><div class="asp" contenteditable="true" style="border:1px dashed silver;margin:10px;padding:5px;background:cornsilk;font-family:monospace;font-size:12px;">',
    '</div><br />'
	],
	[
	'PHP',
    '<br /><div style="position:relative;top:10px;left:10px;font-size:11px;font-family:verdana;">PHP Code</div><div class="asp" contenteditable="true" style="border:1px dashed silver;margin:10px;padding:5px;background:cornsilk;font-family:monospace;font-size:12px;">',
    '</div><br />'
	],
	[
	'Python',
    '<br /><div style="position:relative;top:10px;left:10px;font-size:11px;font-family:verdana;">Python Code</div><div class="asp" contenteditable="true" style="border:1px dashed silver;margin:10px;padding:5px;background:cornsilk;font-family:monospace;font-size:12px;">',
    '</div><br />'
	],
	[
	'Ruby',
    '<br /><div style="position:relative;top:10px;left:10px;font-size:11px;font-family:verdana;">Ruby Code</div><div class="asp" contenteditable="true" style="border:1px dashed silver;margin:10px;padding:5px;background:cornsilk;font-family:monospace;font-size:12px;">',
    '</div><br />'
	],
	[
	'Scheme',
    '<br /><div style="position:relative;top:10px;left:10px;font-size:11px;font-family:verdana;">Scheme Code</div><div class="asp" contenteditable="true" style="border:1px dashed silver;margin:10px;padding:5px;background:cornsilk;font-family:monospace;font-size:12px;">',
    '</div><br />'
	],
	[
	'SQL',
    '<br /><div style="position:relative;top:10px;left:10px;font-size:11px;font-family:verdana;">SQL Code</div><div class="asp" contenteditable="true" style="border:1px dashed silver;margin:10px;padding:5px;background:cornsilk;font-family:monospace;font-size:12px;">',
    '</div><br />'
	],
	[
	'VB.NET',
    '<br /><div style="position:relative;top:10px;left:10px;font-size:11px;font-family:verdana;">VB.NET Code</div><div class="asp" contenteditable="true" style="border:1px dashed silver;margin:10px;padding:5px;background:cornsilk;font-family:monospace;font-size:12px;">',
    '</div><br />'
	],
	[
	'XML',
    '<br /><div style="position:relative;top:10px;left:10px;font-size:11px;font-family:verdana;">XML Code</div><div class="asp" contenteditable="true" style="border:1px dashed silver;margin:10px;padding:5px;background:cornsilk;font-family:monospace;font-size:12px;">',
    '</div><br />'
	]
];
};