<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>PFF</title>
</head>
<body>

<h2>You have received your password for your account.</h2>

<strong>Your Password</strong>
<p><?php echo $password ; ?></p>
<br>


</body>
</html>

<?php /**PATH C:\xampp\htdocs\seizeit\resources\views/send_user_password.blade.php ENDPATH**/ ?>