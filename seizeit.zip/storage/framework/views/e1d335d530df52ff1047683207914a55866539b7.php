<!DOCTYPE html>
<html lang="en">
<?php include resource_path('views/includes/head.php'); ?>
<style>
    .select2-container {
        width: 25% !important;
    }
 </style>
<body>

<?php include resource_path('views/includes/header.php'); ?>
<?php include resource_path('views/includes/sidebar.php'); ?>
<section class="content lifeContent">

    <?php if(\Session::has('success')): ?>
        <h4 class="alert alert-success fade in">
            <?php echo e(\Session::get('success')); ?>

        </h4>
    <?php endif; ?>
        <a class="btn btn-primary add_s" href="<?php echo e(url('/')); ?>/add/custom/category">Add Sub Category</a>
        <a class="btn btn-primary add_s" href="<?php echo e(url('/')); ?>/add/sub/category">Scrap Categories</a>

    <div class="contentPd">
        
        <h2 class="mainHEading">Sub Categories</h2>
        <?php if($errors->has('delete_ids')): ?>
            <div class="alert alert-danger">
                <?php $__currentLoopData = $errors->get('delete_ids'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($message); ?><br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>


            <form method="GET" action="<?php echo e(url('/sub/categories')); ?>">
                <select class="unis" name="unis">
                    <option value="0">Select Uni</option>
                    <?php $__currentLoopData = $unis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uni): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php if(isset($_GET['unis']) and $_GET['unis'] == $uni->id): ?> selected <?php endif; ?> value="<?php echo e($uni->id); ?>"><?php echo e($uni->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <select class="majors" name="majors">
                    <option value="0">Select Major</option>
                    <?php $__currentLoopData = $majors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $major): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php if(isset($_GET['majors']) and $_GET['majors'] == $major->id): ?> selected <?php endif; ?> value="<?php echo e($major->id); ?>"><?php echo e($major->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>
                <select id="major_categories" class="categories" name="categories">
                    <option value="0">Select Category</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php if(isset($_GET['categories']) and $_GET['categories'] == $category->id): ?> selected <?php endif; ?> value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <input class="btn btn-primary" style="padding: 4px 12px;" type="submit" value="SEARCH">
                <?php if(isset($_GET) and count($_GET) > 0): ?><a href="<?php echo e(url('/sub/categories')); ?>" class="btn btn-primary" style="padding: 4px 12px;">CLEAR </a> <?php endif; ?>
            </form>

        </div>

        <form method="post" action="<?php echo e(url('/')); ?>/sub/category/bulk/delete">
            <?php echo e(csrf_field()); ?>

        <table id="mytable" class="display" cellspacing="0" width="100%">
            <thead>
            <tr>
                <th>Uni</th>
                <th>Major</th>
                <th>Category</th>
                <th>Title</th>
                <th>Description</th>
                <th>Actions</th>
                <th><?php if(!$data->isEmpty()): ?> <input class="btn btn-danger submit" id="bulk_button"  type="submit" value="Delete"> <?php endif; ?></th>
            </tr>
            </thead>
            <tbody>
            <?php if(isset($data)): ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr id="<?php echo e($dat->id); ?>">
                        <td><?php echo e($dat->uni->name); ?></td>
                        <td><?php echo e(isset($dat->major) ? $dat->major->name : ''); ?></td>
                        <td><?php echo e($dat->category->name); ?></td>
                        <td><?php echo e($dat->title); ?></td>
                        <td style="cursor: pointer"><a data-toggle="modal" data-target="#model-<?php echo e($dat->id); ?>">Description</a></td>
                        

                        <td>
                            <a href=<?php echo e(url('/')); ?>/update/sub/category/<?php echo e($dat->id); ?>><i class="fa fa-edit fa-fw"></i></a>
                            <a href=<?php echo e(url('/')); ?>/delete/sub/category/<?php echo e($dat->id); ?>><i class="fa fa-trash fa-fw "></i></a>
                        </td>
                        <td><input class="delete_check" type="checkbox" value="<?php echo e($dat->id); ?>" name="delete_ids[]"></td>
                    </tr>

                    <div class="modal fade" id="model-<?php echo e($dat->id); ?>" role="dialog">
                        <div class="modal-dialog">

                            <!-- Modal content-->
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    <h4 class="modal-title">Detail</h4>
                                </div>
                                <div class="modal-body">
                                            <span><b>Uni</b></span>
                                            <P><?php echo e($dat->uni->name); ?></P>
                                            <br>
                                    <span><b>Major</b></span>
                                    <P><?php echo e(isset($dat->major) ? $dat->major->name : ''); ?></P>
                                    <br>
                                    <span><b>Category</b></span>
                                    <P><?php echo e($dat->category->name); ?></P>
                                    <br>
                                    <span><b>Title</b></span>
                                    <P><?php echo e($dat->title); ?></P>
                                    <br>
                                    <span><b>Category</b></span>
                                    <P><?php echo e($dat->title); ?></P>
                                    <br>
                                    <span><b>Email</b></span>
                                    <P><?php echo e($dat->email); ?></P>
                                    <br>
                                    <span><b>Address</b></span>
                                    <P><?php echo e($dat->address); ?></P>
                                    <br>
                                    <span><b>Link</b></span>
                                    <P><?php echo e($dat->link); ?></P>
                                    <br>
                                    <span><b>Description</b></span>
                                    <P><?php echo e($dat->description); ?></P>
                                    <br>
                                    <span><b>Summary</b></span>
                                    <P><?php echo e($dat->summary); ?></P>
                                    <br>


                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                </div>
                            </div>

                        </div>
                    </div>


                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            </tbody>
        </table>
        </form>
        <?php if(!$data->isEmpty()): ?> <p style="margin-top: 10px"><label><input type="checkbox" id="checkAll"/> Check all</label></p> <?php endif; ?>
        <?php echo e($data->appends($_GET)->links()); ?>




</section>
<?php include resource_path('views/includes/footer.php'); ?>

<script>

    $(document).ready(function() {
        $('.categories').select2();
    });

    $(document).ready(function() {
        $('.majors').select2();
    });
    $(document).ready(function() {
        $('.unis').select2();
    });

    $(document).ready( function () {
        table =  $('#mytable').DataTable();
    });
    $('#mytable').dataTable({
        "bPaginate": false,
        "info":     false,
          "bSort": false,
        "bLengthChange": false,
        "bFilter": true,
    });
    $('.dataTables_filter').hide();

</script>
<?php /**PATH C:\xampp\htdocs\seizeit\resources\views/major_categories/sub_categories.blade.php ENDPATH**/ ?>