<html lang="en">
<?php include resource_path('views/includes/head.php'); ?>
<body>
<?php include resource_path('views/includes/header.php'); ?>
<?php include resource_path('views/includes/sidebar.php'); ?>
<section class="content publicContent editEvent">

    <div class="content lifeContent">
        <div class="heading-sponser">
            <h2>Add Sub Category</h2>
            <a class="btn btn btn-primary back" href="<?php echo e(url('/')); ?>/sub/categories">Back</a>
        </div>
        <div class="userForm user">

            <?php if(\Session::has('success')): ?>
                <h4 class="alert alert-success fade in">
                    <?php echo e(\Session::get('success')); ?>

                </h4>
            <?php endif; ?>
                <?php if(\Session::has('error')): ?>
                    <h4 class="alert alert-error fade in">
                        <?php echo e(\Session::get('error')); ?>

                    </h4>
                <?php endif; ?>
            <form action="<?php echo e(url('/')); ?>/add/custom/category" method="post" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <label class="fullField">
                    <span class="required">Select Uni</span>
                    <select class="unis" name="uni_id[]" multiple required>
                        <?php $__currentLoopData = $unis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uni): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($uni->id); ?>"><?php echo e($uni->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </select>
                    <?php if($errors->has('uni_id')): ?>
                        <div class="alert alert-danger">
                            <?php $__currentLoopData = $errors->get('uni_id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($message); ?><br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                </label>

                <label class="fullField">
                    <span>Select Major</span>
                    <select class="majors" name="major_id[]" multiple>
                        <?php $__currentLoopData = $majors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $major): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php if(request()->route()->parameter('major_id') == $major->id): ?> selected <?php endif; ?> value="<?php echo e($major->id); ?>"><?php echo e($major->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </select>
                    <?php if($errors->has('major_id')): ?>
                        <div class="alert alert-danger">
                            <?php $__currentLoopData = $errors->get('major_id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($message); ?><br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                </label>

                <label class="fullField">
                    <span class="required">Select Category</span>
                    <select id="major_categories" class="categories" multiple required name="category_id[]">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has('category_id')): ?>
                        <div class="alert alert-danger">
                            <?php $__currentLoopData = $errors->get('category_id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($message); ?><br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                </label>

                <label class="fullField">
                    <span>Title</span>
                    <input type="text" name="title" value="<?php echo e(old('title')); ?>">
                    <?php if($errors->has('title')): ?>
                        <div class="alert alert-danger">
                            <?php $__currentLoopData = $errors->get('title'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($message); ?><br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                </label>
                <label class="fullField">
                    <span>Email</span>
                    <input type="text" name="email" value="<?php echo e(old('email')); ?>">
                    <?php if($errors->has('email')): ?>
                        <div class="alert alert-danger">
                            <?php $__currentLoopData = $errors->get('email'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($message); ?><br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                </label>
                <label class="fullField">
                    <span>Address</span>
                    <input type="text" name="address" value="<?php echo e(old('address')); ?>">
                    <?php if($errors->has('address')): ?>
                        <div class="alert alert-danger">
                            <?php $__currentLoopData = $errors->get('address'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($message); ?><br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                </label>
                <label class="fullField">
                    <span>Link</span>
                    <textarea name="link"><?php echo e(old('link')); ?></textarea>
                    <?php if($errors->has('link')): ?>
                        <div class="alert alert-danger">
                            <?php $__currentLoopData = $errors->get('link'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($message); ?><br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                </label>
                <label class="fullField">
                    <span>Description</span>
                    <textarea name="description"><?php echo e(old('description')); ?></textarea>
                    <?php if($errors->has('description')): ?>
                        <div class="alert alert-danger">
                            <?php $__currentLoopData = $errors->get('description'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($message); ?><br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                </label>
                <label class="fullField">
                    <span>Summary</span>
                    <textarea name="summary"><?php echo e(old('summary')); ?></textarea>
                    <?php if($errors->has('summary')): ?>
                        <div class="alert alert-danger">
                            <?php $__currentLoopData = $errors->get('summary'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($message); ?><br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                </label>

                <input type="hidden" name="_token" id="token" value="<?php echo e(csrf_token()); ?>">
                <br>
                <br>
                <div class="btnCol">
                    <input class="btn btn-primary" type="submit" name="signIn"  value="Submit">
                </div>
            </form>
        </div>
    </div>
</section>
<?php include resource_path('views/includes/footer.php'); ?>

<script src="<?php echo e(URL::to('src/js/vendor/tinymce/js/tinymce/tinymce.min.js')); ?>"></script>

<script>

    $(document).ready(function() {
        $('.categories').select2();
    });

    $(document).ready(function() {
        $('.majors').select2();
        $('.unis').select2();
    });

    var category_id = 0;
    var major_id = 0;
    var skip = 0;

    function selectMajor(elm)
    {
        major_id = elm.value;

        $("#major_categories option").each(function() {
            $(this).remove();
        });

        $.ajax({
            url: base_url + '/get-major-category',
            type : "GET",
            headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
            data : {'major_id':major_id},
            success: function(data){
                if(data.status)
                {
                    for(var i = 0; i < data.categories.length; i++) {
                        $('#major_categories').append(`<option value="${data.categories[i]['id']}">
                                       ${data.categories[i]['name']}
                                  </option>`);
                    }
                }
            }
        });
    }
    function selectCategory(elm)
    {
        category_id = elm.value;
    }
    function addSub() {
        $.ajax({
            url: base_url + '/add/sub/category',
            type : "POST",
            headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
            data : {'skip': 0,'major_id':major_id , 'category_id':category_id,"_token": "<?php echo e(csrf_token()); ?>"},
            success: function(data){
                if(!data.status)
                {
                    $('#submit_button').prop('disabled', true);
                    $('.majors').prop('disabled', true);
                    $('.categories').prop('disabled', true);
                    skip = data.skip;
                    $('#status').text(data.inserted+' sub categories added');
                    addSub();
                }
                else {
                    $('#submit_button').prop('disabled', false);
                    $('#status').text('All categories are added');
                    $('.majors').prop('disabled', false);
                    $('.categories').prop('disabled', false);
                }
            }
        });
    }

</script>
<?php /**PATH C:\xampp\htdocs\seizeit\resources\views/major_categories/add_custom_category.blade.php ENDPATH**/ ?>