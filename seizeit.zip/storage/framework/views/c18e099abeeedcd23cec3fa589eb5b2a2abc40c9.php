<!DOCTYPE html>
<html lang="en">
<?php include resource_path('views/includes/head.php'); ?>
<body>

<?php include resource_path('views/includes/header.php'); ?>
<?php include resource_path('views/includes/sidebar.php'); ?>
<section class="content lifeContent">

    <?php if(\Session::has('success')): ?>
        <h4 class="alert alert-success fade in">
            <?php echo e(\Session::get('success')); ?>

        </h4>
    <?php endif; ?>
        <a class="add_s" href="<?php echo e(url('/')); ?>/add/speaker" >Add New Speaker</a>
        <form class="add_s" action="<?php echo e(url('/')); ?>/speakers" method="get">
            <input name="sort_status" value="0" type="hidden">
            <input type="submit" name="submit" value="Sort By Name">
        </form>

    <div class="contentPd">
        
        <h2 class="mainHEading">Speakers</h2>
        <?php if($errors->has('delete_ids')): ?>
            <div class="alert alert-danger">
                <?php $__currentLoopData = $errors->get('delete_ids'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($message); ?><br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
        <form method="post" action="<?php echo e(url('/')); ?>/speaker/bulk/delete">
            <?php echo e(csrf_field()); ?>

        <table id="tableStyle" class="display" cellspacing="0" width="100%">
            <thead>
            <tr>
                <th>Name</th>
                <th>Designation</th>
                <th>Detail</th>
                <th>Actions</th>
                <th><?php if(!$speakers->isEmpty()): ?> <input class="submit" id="bulk_button"  type="submit" value="Delete" > <?php endif; ?></th>
            </tr>
            </thead>
            <tbody id="sortable">
            <?php if(isset($speakers)): ?>
                <?php $__currentLoopData = $speakers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $speaker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr id="<?php echo e($speaker->id); ?>">
                        <td><?php echo e($speaker['name']); ?></td>
                        <td><?php echo e($speaker['designation']); ?></td>
                        <td><a href=<?php echo e(url('/')); ?>/speaker/detail/<?php echo e($speaker->id); ?>>View</a></td>
                        <td class="list-table">
                            <a href=<?php echo e(url('/')); ?>/update/speaker/<?php echo e($speaker->id); ?>><i class="fa fa-edit fa-fw "></i></a>
                            <a href=<?php echo e(url('/')); ?>/delete/speaker/<?php echo e($speaker->id); ?>><i class="fa fa-trash fa-fw "></i></a>
                        </td>
                        <td><input class="delete_check" type="checkbox" id="bulk_check" value="<?php echo e($speaker->id); ?>" name="delete_ids[]"></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            </tbody>
        </table>
        </form>
        <?php if(!$speakers->isEmpty()): ?> <p><label><input type="checkbox" id="checkAll"/> Check all</label></p> <?php endif; ?>
    </div>
</section>
<?php include resource_path('views/includes/footer.php'); ?>

<script>

    $(function() {
        $("#sortable").sortable();
        $("#sortable").disableSelection();
    });




    $('#sortable').sortable({
        axis: 'y',
        stop: function (event, ui) {
            $.map($(this).find('tr') , function(el){
                var itemId = el.id;
                var itemIndex = $(el).index();
                console.log(itemId);
                console.log(itemIndex);
                var base_url = "<?php echo url('/'); ?>";
                $.ajax({
                    url: base_url + '/sort/speakers',
                    type : "POST",
                    dataType : 'json',
                    data : {itemId:itemId , itemIndex:itemIndex},
                    success: function(data){
                        console.log('success');
                    }
                });
            })
        }
    });
</script>
<?php /**PATH C:\xampp\htdocs\seizeit\resources\views/speakers/uni.blade.php ENDPATH**/ ?>
