<!DOCTYPE html>
<html lang="en">
<?php include resource_path('views/includes/head.php'); ?>
<body>

<?php include resource_path('views/includes/header.php'); ?>
<?php include resource_path('views/includes/sidebar.php'); ?>
<section class="content lifeContent">

    <?php if(\Session::has('success')): ?>
        <h4 class="alert alert-success fade in">
            <?php echo e(\Session::get('success')); ?>

        </h4>
    <?php endif; ?>
        <a class="btn btn btn-primary back" href="<?php echo e(url('/')); ?>/uni">Back</a>
    <div class="contentPd">
        
        <h2 class="mainHEading">Uni Detail</h2>
        
        <span><b>Name</b></span>
        <P><?php echo e($uni->name); ?></P>
        <br>
        
        <span><b>Description</b></span>
        <P><?php echo $uni->uni_detail; ?></P>
        <br>
        
    </div>
</section>
<?php include resource_path('views/includes/footer.php'); ?>
<?php /**PATH C:\xampp\htdocs\seizeit\resources\views/uni/uni_detail.blade.php ENDPATH**/ ?>