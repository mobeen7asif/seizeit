<!DOCTYPE html>
<html lang="en">
<?php include resource_path('views/includes/head.php'); ?>
<body>

<?php include resource_path('views/includes/header.php'); ?>
<?php include resource_path('views/includes/sidebar.php'); ?>
<section class="content lifeContent">

    <?php if(\Session::has('success')): ?>
        <h4 class="alert alert-success fade in">
            <?php echo e(\Session::get('success')); ?>

        </h4>
    <?php endif; ?>
        <a class="btn btn-primary add_s" href="<?php echo e(url('/')); ?>/add/uni" >Add New Uni</a>
        <form class="add_s" action="<?php echo e(url('/')); ?>/uni" method="get">
            <input name="sort_status" value="0" type="hidden">
            
        </form>

    <div class="contentPd">
        
        <h2 class="mainHEading">Universities</h2>
        <?php if($errors->has('delete_ids')): ?>
            <div class="alert alert-danger">
                <?php $__currentLoopData = $errors->get('delete_ids'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($message); ?><br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
        <form method="post" action="<?php echo e(url('/')); ?>/uni/bulk/delete">
            <?php echo e(csrf_field()); ?>

        <table id="tableStyle" class="display" cellspacing="0" width="100%">
            <thead>
            <tr>
                <th>Name</th>
                <th>Description</th>
                $<th>Description</th>
                <th>Status</th>
                <th>Actions</th>
                <th><?php if(count($unis) > 0): ?> <input class="btn btn-danger submit" id="bulk_button"  type="submit" value="Delete" > <?php endif; ?></th>
            </tr>
            </thead>
            <tbody id="sortable">
            <?php if(isset($unis)): ?>
                <?php $__currentLoopData = $unis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uni): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr id="<?php echo e($uni->id); ?>">
                        <td><?php echo e($uni->name); ?></td>
                        <td><?php echo e($uni->uni_detail); ?></td>
                        <td><?php if($uni->status == 1): ?><a href=<?php echo e(url('/')); ?>/uni/detail/<?php echo e($uni->id); ?>>View</a><?php endif; ?></td>
                        <td><?php if($uni->status == 0): ?> <a href="<?php echo e(url('/uni/status/'.$uni->id.'/1')); ?>">Activate</a> <?php else: ?> <a href="<?php echo e(url('/uni/status/'.$uni->id.'/0')); ?>">De Activate</a> <?php endif; ?></td>
                        <td class="list-table">
                            <a href=<?php echo e(url('/')); ?>/update/uni/<?php echo e($uni->id); ?>><i class="fa fa-edit fa-fw "></i></a>
                            <a href=<?php echo e(url('/')); ?>/delete/uni/<?php echo e($uni->id); ?>><i class="fa fa-trash fa-fw "></i></a>
                        </td>
                        <td><input class="delete_check" type="checkbox" id="bulk_check" value="<?php echo e($uni->id); ?>" name="delete_ids[]"></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            </tbody>
        </table>
        </form>
        <?php if(count($unis) > 0): ?> <p><label><input type="checkbox" id="checkAll"/> Check all</label></p> <?php endif; ?>
    </div>
</section>
<?php include resource_path('views/includes/footer.php'); ?>

<script>

    $(function() {
        $("#sortable").sortable();
        $("#sortable").disableSelection();
    });




    $('#sortable').sortable({
        axis: 'y',
        stop: function (event, ui) {
            $.map($(this).find('tr') , function(el){
                var itemId = el.id;
                var itemIndex = $(el).index();
                console.log(itemId);
                console.log(itemIndex);
                var base_url = "<?php echo url('/'); ?>";
                $.ajax({
                    url: base_url + '/sort/uni',
                    type : "POST",
                    dataType : 'json',
                    data : {itemId:itemId , itemIndex:itemIndex},
                    success: function(data){
                        console.log('success');
                    }
                });
            })
        }
    });
</script>
<?php /**PATH C:\xampp\htdocs\seizeit\resources\views/uni/uni.blade.php ENDPATH**/ ?>