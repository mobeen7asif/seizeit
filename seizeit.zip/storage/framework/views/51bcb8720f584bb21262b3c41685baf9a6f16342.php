<html lang="en">
<?php include resource_path('views/includes/head.php'); ?>
<body>
<?php include resource_path('views/includes/header.php'); ?>
<?php include resource_path('views/includes/sidebar.php'); ?>
<section class="content publicContent editEvent">

    <div class="content lifeContent">
        <div class="heading-sponser">
        <h2>Add Sub Category</h2>
            <a class="btn btn btn-primary back" href="<?php echo e(url('/')); ?>/sub/categories">Back</a>
    </div>
        <div id="loader" style="display: none">
            <img src="<?php echo e(url('')); ?>/images/loader.gif">
        </div>
        <div  class="userForm user">

            <?php if(\Session::has('success')): ?>
                <h4 class="alert alert-success fade in">
                    <?php echo e(\Session::get('success')); ?>

                </h4>
            <?php endif; ?>
            <?php echo e(csrf_field()); ?>



            <label class="fullField">
                <span>Select Uni</span>
                <select class="unis" name="majors" multiple onchange="selectUni(this)">
                    <?php $__currentLoopData = $unis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uni): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($uni->id); ?>"><?php echo e($uni->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>
                <?php if($errors->has('majors')): ?>
                    <div class="alert alert-danger">
                        <?php $__currentLoopData = $errors->get('majors'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($message); ?><br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
            </label>

            <label class="fullField">
                <span>Select Major</span>
                <select class="majors" name="majors" multiple onchange="selectMajor(this)">
                    <?php $__currentLoopData = $majors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $major): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php if(request()->route()->parameter('major_id') == $major->id): ?> selected <?php endif; ?> value="<?php echo e($major->id); ?>"><?php echo e($major->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>
                <?php if($errors->has('majors')): ?>
                    <div class="alert alert-danger">
                        <?php $__currentLoopData = $errors->get('majors'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($message); ?><br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
            </label>

            <label class="fullField">
                <span>Select Category</span>
                <select id="major_categories" class="categories" multiple name="categories" onchange="selectCategory(this)">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('categories')): ?>
                    <div class="alert alert-danger">
                        <?php $__currentLoopData = $errors->get('categories'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($message); ?><br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
            </label>

                <label class="fullField">
                    <span>Select Link</span>
                    <select  class="links" name="links" onchange="selectLink(this)">
                        <option value="0">Select Link</option>
                        <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($link->id); ?>"><?php echo e($link->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has('categories')): ?>
                        <div class="alert alert-danger">
                            <?php $__currentLoopData = $errors->get('categories'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($message); ?><br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                </label>

            <input type="hidden" name="_token" id="token" value="<?php echo e(csrf_token()); ?>">

            <span style="font-weight: bold" id="status"></span>
            <br>
            <br>
            <div class="btnCol">
                <input class="btn btn-primary" id="submit_button" onclick="addSub(this)" type="button" name="signIn"  value="Submit">
            </div>
        </div>

    </div>
</section>
<?php include resource_path('views/includes/footer.php'); ?>

<script src="<?php echo e(URL::to('src/js/vendor/tinymce/js/tinymce/tinymce.min.js')); ?>"></script>

<script>

    $(document).ready(function() {
        $('.categories').select2();
    });

    $(document).ready(function() {
        $('.majors').select2();
    });
    $(document).ready(function() {
        $('.unis').select2();
    });
    $(document).ready(function() {
        $('.links').select2();
    });

    var category_id = 0;
    var major_id = 0;
    var skip = 0;

    var unis = [];
    var majors = [];
    var categories = [];
    var link = '';

    function selectUni(uni) {
        unis = $('.unis').val();
    }
    function selectMajor(uni) {
        majors = $('.majors').val();
    }
    function selectCategory(elm)
    {
        categories = $('.categories').val();
    }
    function selectLink(elm) {
        link = $('.links').val();
    }
/*    $('.unis').on('select2:unselecting', function (e) {
        alert('You clicked on X'+e.value);
    });
    $('.unis').on('select2:selecting', function (e) {
        alert('You asdasd on X'+e.value);
    });*/


    function addSub() {
        if(unis.length == 0) {
            alert('Please select uni');
            return false;
        }
        if(majors.length == 0) {
            alert('Please select major');
            return false;
        }
        if(link == 0) {
            alert('Please select link');
            return false;
        }
        if(categories.length == 0) {
            alert('Please select category');
            return false;
        }
        $('#submit_button').prop('disabled', true);
        $('#submit_button').addClass('disable_cursor');
        $('.unis').prop('disabled', true);
        $('.majors').prop('disabled', true);
        $('.categories').prop('disabled', true);
        $('#loader').show();

        $.ajax({
            url: base_url + '/add/sub/category',
            type : "POST",
            headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
            data : {'skip': 0,'major_id':majors , 'link': link,'category_id':categories,'uni_id':unis,"_token": "<?php echo e(csrf_token()); ?>"},
            success: function(data){
                if(data.status == 500){
                    $('#loader').hide();
                    alert('Something went wrong');
                }
                else {
                    $('#loader').hide();
                    alert(data.message);
                    $('#submit_button').prop('disabled', false);
                    $('#submit_button').addClass('disable_cursor');
                    $('.unis').prop('disabled', false);
                    $('.majors').prop('disabled', false);
                    $('.categories').prop('disabled', false);
                }
            }
        });
    }

</script>
<?php /**PATH C:\xampp\htdocs\seizeit\resources\views/major_categories/add_sub_category.blade.php ENDPATH**/ ?>