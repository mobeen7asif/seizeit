<!DOCTYPE html>
<html lang="en">
<?php include resource_path('views/includes/head.php'); ?>
<body>

<?php include resource_path('views/includes/header.php'); ?>
<?php include resource_path('views/includes/sidebar.php'); ?>
<section class="content lifeContent">

    <?php if(\Session::has('success')): ?>
        <h4 class="alert alert-success fade in">
            <?php echo e(\Session::get('success')); ?>

        </h4>
    <?php endif; ?>
        <a class="btn btn-primary add_s" href="<?php echo e(url('/')); ?>/add/link">Add New Link</a>

    <div class="contentPd">
        
        <h2 class="mainHEading">Links</h2>
        <?php if($errors->has('delete_ids')): ?>
            <div class="alert alert-danger">
                <?php $__currentLoopData = $errors->get('delete_ids'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($message); ?><br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
        <form method="post" action="<?php echo e(url('/')); ?>/link/bulk/delete">
            <?php echo e(csrf_field()); ?>

        <table id="tableStyle" class="display" cellspacing="0" width="100%">
            <thead>
            <tr>
                <th>ID</th>
                <th>NAME</th>
                <th>LINK</th>
                <th>Actions</th>
                <th><?php if(!$links->isEmpty()): ?> <input class="submit btn btn-danger" id="bulk_button"  type="submit" value="Delete"> <?php endif; ?></th>
            </tr>
            </thead>
            <tbody>
            <?php if(isset($links)): ?>
                <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr id="<?php echo e($link->id); ?>">
                        <td><?php echo e($link->id); ?></td>
                        <td><?php echo e($link->name); ?></td>
                        <td><?php echo e(\Illuminate\Support\Str::limit($link->link,60)); ?></td>
                        <td>
                            <a href=<?php echo e(url('/')); ?>/update/link/<?php echo e($link->id); ?>><i class="fa fa-edit fa-fw"></i></a>
                            <a href=<?php echo e(url('/')); ?>/delete/link/<?php echo e($link->id); ?>><i class="fa fa-trash fa-fw "></i></a>
                        </td>
                        <td><input class="delete_check" type="checkbox" value="<?php echo e($link->id); ?>" name="delete_ids[]"></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            </tbody>
        </table>
        </form>
        <?php if(!$links->isEmpty()): ?> <p><label><input type="checkbox" id="checkAll"/> Check all</label></p> <?php endif; ?>
    </div>
</section>
<?php include resource_path('views/includes/footer.php'); ?>

<script>

    $(function() {
        $("#sortable").sortable();
        $("#sortable").disableSelection();
    });


    //    $("#sortable").on("sortupdate", function( event, ui ) {
    //
    //        //var sortedIDs = $("#sortable").sortable("toArray");
    //        var data = $('#sortable').sortable('serialize');
    //        console.log(data);
    //    });

    $('#sortable').sortable({
        axis: 'y',
        stop: function (event, ui) {
            $.map($(this).find('tr') , function(el){
                var itemId = el.id;
                var itemIndex = $(el).index();
                console.log(itemId);
                console.log(itemIndex);
                var base_url = "<?php echo url('/'); ?>";
                $.ajax({
                    url: base_url + '/sort/Links',
                    type : "POST",
                    dataType : 'json',
                    data : {itemId:itemId , itemIndex:itemIndex},
                    success: function(data){
                        console.log('success');
                    }
                });
            })
        }
    });
</script>
<?php /**PATH C:\xampp\htdocs\seizeit\resources\views/links/links.blade.php ENDPATH**/ ?>