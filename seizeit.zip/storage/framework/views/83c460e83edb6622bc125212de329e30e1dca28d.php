<!DOCTYPE html>
<html lang="en">
<?php include resource_path('views/includes/head.php'); ?>
<body>

<?php include resource_path('views/includes/header.php'); ?>
<?php include resource_path('views/includes/sidebar.php'); ?>
<section class="content lifeContent">

    <?php if(\Session::has('success')): ?>
        <h4 class="alert alert-success fade in">
            <?php echo e(\Session::get('success')); ?>

        </h4>
    <?php endif; ?>
        <a class="btn btn-primary add_s" href="<?php echo e(url('/')); ?>/add/category">Add New Category</a>

    <div class="contentPd">
        
        <h2 class="mainHEading">Categories</h2>
        <?php if($errors->has('delete_ids')): ?>
            <div class="alert alert-danger">
                <?php $__currentLoopData = $errors->get('delete_ids'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($message); ?><br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
        <form method="post" action="<?php echo e(url('/')); ?>/category/bulk/delete">
            <?php echo e(csrf_field()); ?>

        <table id="tableStyle" class="display" cellspacing="0" width="100%">
            <thead>
            <tr>
                <th>Image</th>
                <th>Name</th>
                $<th>Description</th>
                <th>Actions</th>
                <th><?php if(!$categories->isEmpty()): ?> <input class="submit btn btn-danger" id="bulk_button"  type="submit" value="Delete"> <?php endif; ?></th>
            </tr>
            </thead>
            <tbody id="sortable">
            <?php if(isset($categories)): ?>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr id="<?php echo e($category->id); ?>">
                        <td><img style="height: 25%; width: 25%" src="<?php echo e(isset($category->image) ? url('/').$category->image : url('/images/no_image.jpg')); ?>"/></td>
                        <td><?php echo e($category->name); ?></td>
                        <td><a href=<?php echo e(url('/')); ?>/category/detail/<?php echo e($category->id); ?>>View</a></td>
                        <td>
                            <a href=<?php echo e(url('/')); ?>/update/category/<?php echo e($category->id); ?>><i class="fa fa-edit fa-fw"></i></a>
                            <a href=<?php echo e(url('/')); ?>/delete/category/<?php echo e($category->id); ?>><i class="fa fa-trash fa-fw "></i></a>
                        </td>
                        <td><input class="delete_check" type="checkbox" value="<?php echo e($category->id); ?>" name="delete_ids[]"></td>
                    </tr>

                    <div class="modal fade" id="model-<?php echo e($category->id); ?>" role="dialog">
                        <div class="modal-dialog">

                            <!-- Modal content-->
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    <h4 class="modal-title">Select Major</h4>
                                </div>
                                <div class="modal-body">
                                    <select class="majors" name="majors">
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                </div>
                            </div>

                        </div>
                    </div>


                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            </tbody>
        </table>
        </form>
        <?php if(!$categories->isEmpty()): ?> <p><label><input type="checkbox" id="checkAll"/> Check all</label></p> <?php endif; ?>
    </div>
</section>
<?php include resource_path('views/includes/footer.php'); ?>

<script>

    $(function() {
        $("#sortable").sortable();
        $("#sortable").disableSelection();
    });


    //    $("#sortable").on("sortupdate", function( event, ui ) {
    //
    //        //var sortedIDs = $("#sortable").sortable("toArray");
    //        var data = $('#sortable').sortable('serialize');
    //        console.log(data);
    //    });

    $('#sortable').sortable({
        axis: 'y',
        stop: function (event, ui) {
            $.map($(this).find('tr') , function(el){
                var itemId = el.id;
                var itemIndex = $(el).index();
                console.log(itemId);
                console.log(itemIndex);
                var base_url = "<?php echo url('/'); ?>";
                $.ajax({
                    url: base_url + '/sort/categories',
                    type : "POST",
                    dataType : 'json',
                    data : {itemId:itemId , itemIndex:itemIndex},
                    success: function(data){
                        console.log('success');
                    }
                });
            })
        }
    });
</script>
<?php /**PATH C:\xampp\htdocs\seizeit\resources\views/categories/categories.blade.php ENDPATH**/ ?>