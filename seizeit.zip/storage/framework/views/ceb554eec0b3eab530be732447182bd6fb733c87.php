<html lang="en">
<?php include resource_path('views/includes/head.php'); ?>
<body>
<?php include resource_path('views/includes/header.php'); ?>
<?php include resource_path('views/includes/sidebar.php'); ?>
<section class="content publicContent editEvent">
    <div class="content lifeContent">
        <div class="heading-sponser">
            <h2>Update User</h2>
            <a class="btn btn btn-primary back" href="<?php echo e(url('/')); ?>/admins">Back</a>
        </div>
        <div class="userForm">
            <?php if(\Session::has('success')): ?>
                <h4 class="alert alert-success fade in">
                    <?php echo e(\Session::get('success')); ?>

                </h4>
            <?php endif; ?>
            <form action="<?php echo e(url('/')); ?>/update/user/<?php echo e($user->id); ?>" method="post" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <label class="fullField">
                    <span>First Name</span>
                    <input type="text" name="first_name" value="<?php echo e($user->first_name); ?>">
                    <?php if($errors->has('first_name')): ?>
                        <div class="alert alert-danger">
                            <?php $__currentLoopData = $errors->get('first_name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($message); ?><br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                </label>
                <label class="fullField">
                    <span>Last Name</span>
                    <input type="text" name="last_name" value="<?php echo e($user->last_name); ?>">
                    <?php if($errors->has('last_name')): ?>
                        <div class="alert alert-danger">
                            <?php $__currentLoopData = $errors->get('last_name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($message); ?><br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                </label>
                <label class="fullField">
                    <span>Phone</span>
                    <input type="text" name="phone" value="<?php echo e($user->phone); ?>">
                    <?php if($errors->has('phone')): ?>
                        <div class="alert alert-danger">
                            <?php $__currentLoopData = $errors->get('phone'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($message); ?><br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                </label>
                <label class="fullField">
                    <span>User Email</span>
                    <input type="text" name="email" value="<?php echo e($user->email); ?>">
                    <?php if($errors->has('email')): ?>
                        <div class="alert alert-danger">
                            <?php $__currentLoopData = $errors->get('email'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($message); ?><br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                </label>
                <label class="fullField">
                    <span>User Name</span>
                    <input type="text" name="user_name" value="<?php echo e($user->user_name); ?>">
                    <?php if($errors->has('user_name')): ?>
                        <div class="alert alert-danger">
                            <?php $__currentLoopData = $errors->get('user_name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($message); ?><br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                </label>
                <label class="fullField">
                    <span>Password</span>
                    <input type=text name="password">
                    <?php if($errors->has('password')): ?>
                        <div class="alert alert-danger">
                            <?php $__currentLoopData = $errors->get('password'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($message); ?><br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                </label>
                <div class="btnCol">
                    <input class="btn btn-primary" type="submit" name="signIn"  value="Submit">
                </div>
            </form>
        </div>
    </div>
</section>
<?php include resource_path('views/includes/footer.php'); ?>
<?php /**PATH C:\xampp\htdocs\seizeit\resources\views/users/edit_user.blade.php ENDPATH**/ ?>