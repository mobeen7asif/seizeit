<head>
        <meta charset="UTF-8">
        <meta name="robots" content="noindex, nofollow" />
        <meta name="csrf_token" content="<?php echo csrf_token(); ?>" />
        <title>SEIZEIT Admin</title>

        <meta name="viewport" content="public/width=device-width">
        <link rel="stylesheet" href="<?php echo asset('css/bootstrap.min.css'); ?>">
        <link rel="stylesheet" href="<?php echo asset('css/font-awesome.min.css'); ?>">
        <link rel="stylesheet" href="<?php echo asset('css/jquery.dataTables.css'); ?>">
        <link rel="stylesheet" href="<?php echo asset('css/jquery.mCustomScrollbar.min.css'); ?>">
        <link rel="stylesheet" href="<?php echo asset('css/normalize.css'); ?>">
        <link rel="stylesheet" href="<?php echo asset('css/theme.css'); ?>">
        <link rel="stylesheet" href="<?php echo asset('admin/css/jquery.fancybox.css'); ?>">
        <link rel="stylesheet" type="text/css" href="http://cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.css"/>
        <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
        <link rel="stylesheet" type="text/css" href="<?php echo asset('css/multi_select.css'); ?>">
    <link href="https://cdn.jsdelivr.net/npm/select2@4.0.12/dist/css/select2.min.css" rel="stylesheet" />




</head>
