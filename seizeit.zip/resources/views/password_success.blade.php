<html lang="en">
<?php include resource_path('views/includes/head.php'); ?>
<body>
<?php include resource_path('views/includes/header.php'); ?>
<section class="content publicContent loginPage no-top-padding">
    <div class="contentPd">
        <div class="form-area">
            <div class="form-holder">
                <div class="userForm">
                    <h4>Password has changed successfully</h4>
                </div>
            </div>
        </div>
    </div>
</section>
<?php include resource_path('views/includes/footer.php'); ?>
