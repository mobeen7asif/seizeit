<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<h1>Click the following link to change your password.</h1>
<a href="{{url('/')}}/redirect_link?user={{$id}}&token={{$token}}">Reset</a>
</body>
</html>