<script src="<?php echo url('/');?>/js/jquery.min.js"></script>
<script src="<?php echo url('/'); ?>/js/bootstrap.min.js"></script>
<script src="<?php echo url('/'); ?>/js/jquery.dataTables.js"></script>

<script src="<?php echo asset('/'); ?>/js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="<?php echo url('/'); ?>/js/mian.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

<script src="http://jqueryvalidation.org/files/dist/jquery.validate.min.js"></script>
<script src="http://jqueryvalidation.org/files/dist/additional-methods.min.js"></script>


<script type="text/javascript" src="<?php echo url('/'); ?>/js/multi_select.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.0.12/dist/js/select2.min.js"></script>






</body>
</html>
